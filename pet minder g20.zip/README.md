# pet-minder-SE-20

To run the program:
1. npm install -g live-server
2. Launch `live-server` in root directory
3. Navigate to `pages/preSignIn/homepage.html` in the page.